# Apêndices técnicos do TCC

Arquivos separados a partir do material enviado no chat para organização em repositório Git.

## Arquivos

- `apendice_a_consultas_sql.md`: consultas SQL utilizadas na construção das bases analíticas.
- `apendice_b_medidas_dax.md`: medidas DAX criadas no modelo semântico.
- `apendice_c_script_python.md`: script Python para extração e tratamento dos dados de EBITDA.

## Observação de geração

O Apêndice A foi separado com as consultas 1 a 32. Os Apêndices B e C foram iniciados em arquivos separados, mas precisam ser completados/revisados a partir do texto original integral antes do upload final no repositório.
